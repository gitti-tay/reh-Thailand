# re:H Thailand — Official Website

Advanced Air Subcision Microneedling (SSCM™) technology platform. Full-stack React + Express application with SQLite database, designed for deployment on Railway.

## Tech Stack

- **Frontend:** React 18, Vite, Tailwind CSS 4
- **Backend:** Express.js, better-sqlite3, Nodemailer
- **Deployment:** Railway (via GitHub)

## Features

### Frontend
- Responsive marketing website (mobile-first)
- SSCM technology showcase with comparison tables
- Interactive clinic finder with search & region filtering
- Demo request form with validation
- Partner enquiry modal
- Newsletter subscription
- Video showcase section
- Testimonials from medical professionals
- Google Maps directions integration

### Backend API
- `POST /api/demo-request` — Submit clinical demo request
- `POST /api/partner-enquiry` — Submit partnership application
- `POST /api/contact` — Send contact message
- `POST /api/newsletter/subscribe` — Subscribe to newsletter
- `POST /api/newsletter/unsubscribe` — Unsubscribe
- `GET  /api/clinics` — Get certified clinics (filter by region/search)
- `GET  /api/clinics/regions` — Get available regions
- `POST /api/analytics/event` — Track analytics events
- `GET  /api/health` — Health check endpoint
- **Admin endpoints** (requires `X-Admin-Key` header):
  - `GET /api/demo-requests` — List all demo requests
  - `PUT /api/demo-requests/:id/status` — Update request status
  - `GET /api/analytics/summary` — Dashboard analytics
  - `GET /api/admin/leads` — All leads overview

## Local Development

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/reh-thailand-website.git
cd reh-thailand-website

# 2. Install dependencies
npm install

# 3. Copy environment variables
cp .env.example .env

# 4. Run both frontend + backend
npm run dev

# Frontend: http://localhost:5173 (proxies API to :3001)
# Backend:  http://localhost:3001/api
```

## Deploy to Railway via GitHub

### Step 1: Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: re:H Thailand full-stack website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/reh-thailand-website.git
git push -u origin main
```

### Step 2: Deploy on Railway

1. Go to [railway.app](https://railway.app) and sign in with GitHub
2. Click **"New Project"** → **"Deploy from GitHub Repo"**
3. Select **reh-thailand-website** repository
4. Railway auto-detects the `railway.json` config

### Step 3: Configure Environment Variables

In Railway dashboard → your service → **Variables** tab, set:

| Variable | Value |
|----------|-------|
| `NODE_ENV` | `production` |
| `PORT` | `3001` |
| `ADMIN_API_KEY` | (generate a secure random key) |

**Optional — Email notifications:**

| Variable | Value |
|----------|-------|
| `SMTP_HOST` | `smtp.gmail.com` |
| `SMTP_PORT` | `587` |
| `SMTP_USER` | your email |
| `SMTP_PASS` | your app password |
| `NOTIFICATION_EMAIL` | `sales@jnacorporation.com` |

### Step 4: Add Persistent Storage (recommended)

1. In Railway, click **"+ New"** → **"Volume"**
2. Mount path: `/data`
3. Add variable: `DATABASE_PATH=/data`
4. This persists the SQLite database across deploys

### Step 5: Generate Domain

1. Go to **Settings** → **Networking**
2. Click **"Generate Domain"** for a `*.railway.app` URL
3. Or add a custom domain

## Project Structure

```
├── index.html              # Entry HTML
├── package.json            # Dependencies & scripts
├── vite.config.ts          # Vite + Tailwind config
├── tsconfig.json           # TypeScript config
├── railway.json            # Railway deployment config
├── nixpacks.toml           # Nixpacks build config
├── Procfile                # Process definition
├── .env.example            # Environment template
├── server/
│   ├── index.js            # Express server entry
│   ├── database.js         # SQLite init + schema
│   ├── email.js            # Nodemailer notifications
│   └── routes/
│       └── api.js          # All API routes
├── src/
│   ├── main.tsx            # React entry
│   ├── app/
│   │   ├── App.tsx         # Main app component
│   │   └── components/     # All UI sections
│   ├── services/
│   │   └── api.ts          # Frontend API client
│   ├── imports/            # Figma SVG paths
│   └── styles/             # Tailwind + custom CSS
└── public/
    └── assets/             # Images (logo, device, tips)
```

## Admin Dashboard

Access admin endpoints by including the `X-Admin-Key` header:

```bash
# Get analytics summary
curl -H "X-Admin-Key: YOUR_KEY" https://your-app.railway.app/api/analytics/summary

# Get all demo requests
curl -H "X-Admin-Key: YOUR_KEY" https://your-app.railway.app/api/demo-requests

# Update demo request status
curl -X PUT -H "Content-Type: application/json" -H "X-Admin-Key: YOUR_KEY" \
  -d '{"status":"contacted"}' \
  https://your-app.railway.app/api/demo-requests/1/status
```

## License

Proprietary — re:H Thailand / JNA Corporation
