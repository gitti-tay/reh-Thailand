const API_BASE = import.meta.env.VITE_API_URL || '/api';

interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
}

async function request<T>(endpoint: string, options?: RequestInit): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
      ...options,
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        success: false,
        message: data.message || `Request failed with status ${response.status}`,
      };
    }

    return data;
  } catch (error) {
    console.error(`API error [${endpoint}]:`, error);
    return {
      success: false,
      message: 'Network error. Please check your connection and try again.',
    };
  }
}

// Demo Requests
export async function submitDemoRequest(data: {
  name: string;
  clinic: string;
  email: string;
  phone?: string;
  message?: string;
}) {
  return request('/demo-request', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

// Partner Enquiries
export async function submitPartnerEnquiry(data: {
  clinic_name: string;
  contact_name: string;
  email: string;
  phone?: string;
  location?: string;
  message?: string;
}) {
  return request('/partner-enquiry', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

// Contact Messages
export async function submitContactMessage(data: {
  name: string;
  email: string;
  phone?: string;
  subject?: string;
  message: string;
}) {
  return request('/contact', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

// Newsletter
export async function subscribeNewsletter(email: string) {
  return request('/newsletter/subscribe', {
    method: 'POST',
    body: JSON.stringify({ email }),
  });
}

export async function unsubscribeNewsletter(email: string) {
  return request('/newsletter/unsubscribe', {
    method: 'POST',
    body: JSON.stringify({ email }),
  });
}

// Clinics
export interface Clinic {
  id: number;
  name: string;
  address: string;
  region: string;
  hours: string;
  phone: string;
  email: string;
  website: string;
  latitude: number;
  longitude: number;
  tags: string[];
  is_active: number;
}

export async function getClinics(params?: { region?: string; search?: string }) {
  const queryParams = new URLSearchParams();
  if (params?.region) queryParams.set('region', params.region);
  if (params?.search) queryParams.set('search', params.search);

  const queryString = queryParams.toString();
  return request<Clinic[]>(`/clinics${queryString ? `?${queryString}` : ''}`);
}

export async function getClinicRegions() {
  return request<string[]>('/clinics/regions');
}

// Analytics
export async function trackEvent(eventType: string, eventData?: any, page?: string) {
  // Fire and forget — don't await
  request('/analytics/event', {
    method: 'POST',
    body: JSON.stringify({
      event_type: eventType,
      event_data: eventData,
      page: page || window.location.pathname,
    }),
  }).catch(() => {}); // Silently fail
}

export default {
  submitDemoRequest,
  submitPartnerEnquiry,
  submitContactMessage,
  subscribeNewsletter,
  unsubscribeNewsletter,
  getClinics,
  getClinicRegions,
  trackEvent,
};
