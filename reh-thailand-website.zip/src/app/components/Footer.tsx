import { useState } from "react";
import imgLogo from "figma:asset/1ffbd753ec27789a617aa37d799e86f2761e08d5.png";
import svgPaths from "../../imports/svg-sqg3bg9ea9";
import { subscribeNewsletter, trackEvent } from "../../services/api";

const quickLinks = [
  { label: "SSCM Technology", href: "#technology" },
  { label: "For Clinics", href: "#clinics" },
  { label: "Clinical Evidence", href: "#evidence" },
  { label: "Find a Clinic", href: "#find-clinic" },
  { label: "Request Demo", href: "#demo" },
];

export function Footer() {
  const [email, setEmail] = useState("");
  const [subStatus, setSubStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [subMessage, setSubMessage] = useState("");

  const handleNavClick = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubStatus("loading");

    try {
      const result = await subscribeNewsletter(email);
      if (result.success) {
        setSubStatus("success");
        setSubMessage(result.message || "Subscribed!");
        setEmail("");
        trackEvent("newsletter_subscribe");
        setTimeout(() => setSubStatus("idle"), 4000);
      } else {
        setSubStatus("error");
        setSubMessage(result.message || "Failed to subscribe");
        setTimeout(() => setSubStatus("idle"), 3000);
      }
    } catch {
      setSubStatus("error");
      setSubMessage("Network error. Please try again.");
      setTimeout(() => setSubStatus("idle"), 3000);
    }
  };

  return (
    <footer id="about" className="bg-gradient-to-b from-[#1447e6] to-[rgba(43,127,255,0.5)] pt-20 pb-8">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 mb-12">
          {/* Left — Brand */}
          <div className="flex-1">
            <img
              src={imgLogo}
              alt="re:H Thailand"
              className="h-[48px] w-auto object-contain opacity-90 mb-6"
            />
            <p className="font-['Inter',sans-serif] font-light text-[16px] text-white leading-[1.6] tracking-[-0.31px] max-w-[430px] mb-6">
              Precision microneedling technology for medical aesthetics. TFDA certified, ISO 13485:2016 quality assured.
            </p>

            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className="flex-shrink-0">
                  <path d={svgPaths.p625a980} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                  <path d={svgPaths.p18c84c80} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                </svg>
                <span className="font-['Inter',sans-serif] font-normal text-[14px] text-white tracking-[-0.15px]">
                  Distributed exclusively by JNA Corporation, Thailand
                </span>
              </div>
              <a href="mailto:info@rehthailand.com" className="flex items-center gap-3 no-underline hover:opacity-80 transition-opacity">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className="flex-shrink-0">
                  <path d={svgPaths.p1b122e80} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                  <path d={svgPaths.p17a68100} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                </svg>
                <span className="font-['Inter',sans-serif] font-normal text-[14px] text-white tracking-[-0.15px]">
                  info@rehthailand.com
                </span>
              </a>
              <a href="tel:+66613614599" className="flex items-center gap-3 no-underline hover:opacity-80 transition-opacity">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className="flex-shrink-0">
                  <path d={svgPaths.p32db8200} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                </svg>
                <span className="font-['Inter',sans-serif] font-normal text-[14px] text-white tracking-[-0.15px]">
                  +66 61 361 4599
                </span>
              </a>
            </div>
          </div>

          {/* Right — Quick Links + Newsletter */}
          <div className="lg:w-[340px]">
            <h4 className="font-['Inter',sans-serif] font-semibold text-[14px] text-white tracking-[1.25px] uppercase mb-6">
              Quick Links
            </h4>
            <ul className="flex flex-col gap-3 mb-8">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => handleNavClick(link.href)}
                    className="font-['Inter',sans-serif] font-light text-[14px] text-white tracking-[0.13px] hover:text-[#bedbff] transition-colors bg-transparent border-none cursor-pointer p-0"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>

            {/* Newsletter */}
            <h4 className="font-['Inter',sans-serif] font-semibold text-[14px] text-white tracking-[1.25px] uppercase mb-3">
              Stay Updated
            </h4>
            <form onSubmit={handleSubscribe} className="flex gap-2 mb-3">
              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 h-[40px] px-4 rounded-[8px] border border-white/20 bg-white/10 font-['Inter',sans-serif] text-[13px] text-white placeholder:text-white/50 outline-none focus:border-white/40 transition-colors"
              />
              <button
                type="submit"
                disabled={subStatus === "loading"}
                className="h-[40px] px-4 bg-white/15 border border-white/20 rounded-[8px] font-['Inter',sans-serif] font-medium text-[13px] text-white cursor-pointer hover:bg-white/25 transition-colors disabled:opacity-60 flex-shrink-0"
              >
                {subStatus === "loading" ? "..." : subStatus === "success" ? "✓" : "Subscribe"}
              </button>
            </form>
            {subMessage && (
              <p className={`font-['Inter',sans-serif] text-[12px] ${subStatus === "success" ? "text-[#86efac]" : "text-[#fca5a5]"}`}>
                {subMessage}
              </p>
            )}
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent mb-6" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-['Inter',sans-serif] font-normal text-[12px] text-white tracking-[0.3px]">
            &copy; {new Date().getFullYear()} re:H Thailand. All rights reserved.
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-white" />
              <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">TFDA: 66-1-02-0-0018</span>
            </span>
            <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">&bull;</span>
            <span className="flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-white" />
              <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">ISO 13485:2016</span>
            </span>
            <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">&bull;</span>
            <span className="flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-white" />
              <span className="font-['Inter',sans-serif] font-normal text-[12px] text-white">Korean Patents</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
