import { Router } from 'express';
import { getDb } from '../database.js';
import { sendNotificationEmail } from '../email.js';

const router = Router();

// ============================================================
// DEMO REQUESTS
// ============================================================

// Submit a demo request
router.post('/demo-request', async (req, res) => {
  try {
    const { name, clinic, email, phone, message } = req.body;

    // Validation
    if (!name || !clinic || !email) {
      return res.status(400).json({
        success: false,
        message: 'Name, clinic, and email are required'
      });
    }

    if (!isValidEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address'
      });
    }

    const db = getDb();
    const stmt = db.prepare(`
      INSERT INTO demo_requests (name, clinic, email, phone, message)
      VALUES (?, ?, ?, ?, ?)
    `);

    const result = stmt.run(name, clinic, email, phone || null, message || null);

    // Send email notification (non-blocking)
    sendNotificationEmail({
      type: 'demo_request',
      data: { id: result.lastInsertRowid, name, clinic, email, phone, message }
    }).catch(err => console.error('Email notification failed:', err));

    res.status(201).json({
      success: true,
      message: 'Demo request submitted successfully. We will contact you within 24 hours.',
      data: { id: result.lastInsertRowid }
    });
  } catch (error) {
    console.error('Demo request error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit demo request. Please try again.'
    });
  }
});

// Get all demo requests (admin)
router.get('/demo-requests', authenticateAdmin, (req, res) => {
  try {
    const db = getDb();
    const { status, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    let query = 'SELECT * FROM demo_requests';
    const params = [];

    if (status) {
      query += ' WHERE status = ?';
      params.push(status);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(Number(limit), Number(offset));

    const requests = db.prepare(query).all(...params);
    const total = db.prepare('SELECT COUNT(*) as count FROM demo_requests').get();

    res.json({
      success: true,
      data: requests,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: total.count
      }
    });
  } catch (error) {
    console.error('Get demo requests error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch demo requests' });
  }
});

// Update demo request status (admin)
router.put('/demo-requests/:id/status', authenticateAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['pending', 'contacted', 'scheduled', 'completed', 'cancelled'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Must be one of: ${validStatuses.join(', ')}`
      });
    }

    const db = getDb();
    const stmt = db.prepare('UPDATE demo_requests SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
    const result = stmt.run(status, id);

    if (result.changes === 0) {
      return res.status(404).json({ success: false, message: 'Demo request not found' });
    }

    res.json({ success: true, message: 'Status updated successfully' });
  } catch (error) {
    console.error('Update status error:', error);
    res.status(500).json({ success: false, message: 'Failed to update status' });
  }
});

// ============================================================
// PARTNER ENQUIRIES
// ============================================================

router.post('/partner-enquiry', async (req, res) => {
  try {
    const { clinic_name, contact_name, email, phone, location, message } = req.body;

    if (!clinic_name || !contact_name || !email) {
      return res.status(400).json({
        success: false,
        message: 'Clinic name, contact name, and email are required'
      });
    }

    if (!isValidEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address'
      });
    }

    const db = getDb();
    const stmt = db.prepare(`
      INSERT INTO partner_enquiries (clinic_name, contact_name, email, phone, location, message)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(clinic_name, contact_name, email, phone || null, location || null, message || null);

    sendNotificationEmail({
      type: 'partner_enquiry',
      data: { id: result.lastInsertRowid, clinic_name, contact_name, email, phone, location, message }
    }).catch(err => console.error('Email notification failed:', err));

    res.status(201).json({
      success: true,
      message: 'Partnership enquiry submitted successfully. Our team will review your application.',
      data: { id: result.lastInsertRowid }
    });
  } catch (error) {
    console.error('Partner enquiry error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit partner enquiry. Please try again.'
    });
  }
});

// ============================================================
// CONTACT MESSAGES
// ============================================================

router.post('/contact', async (req, res) => {
  try {
    const { name, email, phone, subject, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and message are required'
      });
    }

    if (!isValidEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address'
      });
    }

    const db = getDb();
    const stmt = db.prepare(`
      INSERT INTO contact_messages (name, email, phone, subject, message)
      VALUES (?, ?, ?, ?, ?)
    `);

    const result = stmt.run(name, email, phone || null, subject || null, message);

    sendNotificationEmail({
      type: 'contact_message',
      data: { id: result.lastInsertRowid, name, email, subject, message }
    }).catch(err => console.error('Email notification failed:', err));

    res.status(201).json({
      success: true,
      message: 'Message sent successfully. We will get back to you shortly.',
      data: { id: result.lastInsertRowid }
    });
  } catch (error) {
    console.error('Contact message error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send message. Please try again.'
    });
  }
});

// ============================================================
// NEWSLETTER
// ============================================================

router.post('/newsletter/subscribe', (req, res) => {
  try {
    const { email } = req.body;

    if (!email || !isValidEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address'
      });
    }

    const db = getDb();

    // Check if already subscribed
    const existing = db.prepare('SELECT * FROM newsletter_subscribers WHERE email = ?').get(email);
    if (existing) {
      if (existing.is_active) {
        return res.json({ success: true, message: 'You are already subscribed!' });
      }
      // Reactivate
      db.prepare('UPDATE newsletter_subscribers SET is_active = 1 WHERE email = ?').run(email);
      return res.json({ success: true, message: 'Welcome back! Your subscription has been reactivated.' });
    }

    db.prepare('INSERT INTO newsletter_subscribers (email) VALUES (?)').run(email);

    res.status(201).json({
      success: true,
      message: 'Successfully subscribed to the newsletter!'
    });
  } catch (error) {
    console.error('Newsletter subscribe error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to subscribe. Please try again.'
    });
  }
});

router.post('/newsletter/unsubscribe', (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    const db = getDb();
    db.prepare('UPDATE newsletter_subscribers SET is_active = 0 WHERE email = ?').run(email);

    res.json({ success: true, message: 'Successfully unsubscribed' });
  } catch (error) {
    console.error('Newsletter unsubscribe error:', error);
    res.status(500).json({ success: false, message: 'Failed to unsubscribe' });
  }
});

// ============================================================
// CLINICS
// ============================================================

router.get('/clinics', (req, res) => {
  try {
    const db = getDb();
    const { region, search } = req.query;

    let query = 'SELECT * FROM clinics WHERE is_active = 1';
    const params = [];

    if (region && region !== 'All Regions') {
      query += ' AND region = ?';
      params.push(region);
    }

    if (search) {
      query += ' AND (name LIKE ? OR address LIKE ? OR tags LIKE ?)';
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }

    query += ' ORDER BY name ASC';

    const clinics = db.prepare(query).all(...params);

    // Parse tags from comma-separated string to array
    const formattedClinics = clinics.map(c => ({
      ...c,
      tags: c.tags ? c.tags.split(',').map(t => t.trim()) : []
    }));

    res.json({
      success: true,
      data: formattedClinics,
      total: formattedClinics.length
    });
  } catch (error) {
    console.error('Get clinics error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch clinics' });
  }
});

router.get('/clinics/regions', (req, res) => {
  try {
    const db = getDb();
    const regions = db.prepare('SELECT DISTINCT region FROM clinics WHERE is_active = 1 ORDER BY region ASC').all();

    res.json({
      success: true,
      data: ['All Regions', ...regions.map(r => r.region)]
    });
  } catch (error) {
    console.error('Get regions error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch regions' });
  }
});

// ============================================================
// ANALYTICS
// ============================================================

router.post('/analytics/event', (req, res) => {
  try {
    const { event_type, event_data, page } = req.body;

    if (!event_type) {
      return res.status(400).json({ success: false, message: 'Event type is required' });
    }

    const db = getDb();
    db.prepare(`
      INSERT INTO analytics_events (event_type, event_data, page, user_agent, ip_address)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      event_type,
      event_data ? JSON.stringify(event_data) : null,
      page || null,
      req.headers['user-agent'] || null,
      req.ip || null
    );

    res.json({ success: true });
  } catch (error) {
    console.error('Analytics event error:', error);
    res.status(204).send(); // Don't fail on analytics errors
  }
});

// Get analytics summary (admin)
router.get('/analytics/summary', authenticateAdmin, (req, res) => {
  try {
    const db = getDb();

    const demoRequests = db.prepare('SELECT COUNT(*) as count FROM demo_requests').get();
    const partnerEnquiries = db.prepare('SELECT COUNT(*) as count FROM partner_enquiries').get();
    const contactMessages = db.prepare('SELECT COUNT(*) as count FROM contact_messages').get();
    const subscribers = db.prepare('SELECT COUNT(*) as count FROM newsletter_subscribers WHERE is_active = 1').get();
    const totalEvents = db.prepare('SELECT COUNT(*) as count FROM analytics_events').get();

    const recentDemos = db.prepare('SELECT COUNT(*) as count FROM demo_requests WHERE created_at >= datetime("now", "-7 days")').get();
    const pendingDemos = db.prepare('SELECT COUNT(*) as count FROM demo_requests WHERE status = "pending"').get();

    res.json({
      success: true,
      data: {
        demo_requests: { total: demoRequests.count, last_7_days: recentDemos.count, pending: pendingDemos.count },
        partner_enquiries: partnerEnquiries.count,
        contact_messages: contactMessages.count,
        newsletter_subscribers: subscribers.count,
        total_events: totalEvents.count
      }
    });
  } catch (error) {
    console.error('Analytics summary error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch analytics' });
  }
});

// ============================================================
// ADMIN DASHBOARD DATA
// ============================================================

router.get('/admin/leads', authenticateAdmin, (req, res) => {
  try {
    const db = getDb();
    const { type = 'all', page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;

    let results = {};

    if (type === 'all' || type === 'demo') {
      results.demo_requests = db.prepare(
        'SELECT * FROM demo_requests ORDER BY created_at DESC LIMIT ? OFFSET ?'
      ).all(Number(limit), Number(offset));
    }

    if (type === 'all' || type === 'partner') {
      results.partner_enquiries = db.prepare(
        'SELECT * FROM partner_enquiries ORDER BY created_at DESC LIMIT ? OFFSET ?'
      ).all(Number(limit), Number(offset));
    }

    if (type === 'all' || type === 'contact') {
      results.contact_messages = db.prepare(
        'SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT ? OFFSET ?'
      ).all(Number(limit), Number(offset));
    }

    res.json({ success: true, data: results });
  } catch (error) {
    console.error('Admin leads error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch leads' });
  }
});

// ============================================================
// HELPERS
// ============================================================

function isValidEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function authenticateAdmin(req, res, next) {
  const apiKey = req.headers['x-admin-key'] || req.query.admin_key;
  const validKey = process.env.ADMIN_API_KEY || 'reh-admin-2024';

  if (!apiKey || apiKey !== validKey) {
    return res.status(401).json({
      success: false,
      message: 'Unauthorized. Admin API key required.'
    });
  }

  next();
}

export default router;
