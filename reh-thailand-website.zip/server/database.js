import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Use persistent volume path on Railway, fallback to local
const DB_DIR = process.env.DATABASE_PATH || path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DB_DIR, 'reh_thailand.db');

let db;

export function getDb() {
  if (!db) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return db;
}

export async function initDatabase() {
  // Ensure data directory exists
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  db = new Database(DB_PATH);

  // Enable WAL mode for better concurrent performance
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  // Create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS demo_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      clinic TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT,
      message TEXT,
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'contacted', 'scheduled', 'completed', 'cancelled')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS partner_enquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      clinic_name TEXT NOT NULL,
      contact_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT,
      location TEXT,
      message TEXT,
      status TEXT DEFAULT 'new' CHECK(status IN ('new', 'reviewing', 'approved', 'declined')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS contact_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT,
      subject TEXT,
      message TEXT NOT NULL,
      status TEXT DEFAULT 'unread' CHECK(status IN ('unread', 'read', 'replied')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS newsletter_subscribers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      subscribed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      is_active INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS clinics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      address TEXT NOT NULL,
      region TEXT NOT NULL,
      hours TEXT,
      phone TEXT,
      email TEXT,
      website TEXT,
      latitude REAL,
      longitude REAL,
      tags TEXT,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS analytics_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_type TEXT NOT NULL,
      event_data TEXT,
      page TEXT,
      user_agent TEXT,
      ip_address TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Seed default clinics if empty
  const clinicCount = db.prepare('SELECT COUNT(*) as count FROM clinics').get();
  if (clinicCount.count === 0) {
    const insertClinic = db.prepare(`
      INSERT INTO clinics (name, address, region, hours, phone, tags, latitude, longitude)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const defaultClinics = [
      ['APEX Surgery Hospital - Ploenchit', '82 Sukhumvit Rd, Bangkok', 'Bangkok', 'Daily: 8:30-20:30', '+66 2 258 8855', 'Surgical Procedures,Advanced Aesthetics', 13.7433, 100.5488],
      ['APEX Beauty - Thonglor', 'Thonglor Soi 8, Sukhumvit, Bangkok', 'Bangkok', 'Daily: 8:30-20:00', '+66 2 712 2222', 'Skin Rejuvenation,SSCM Treatments', 13.7322, 100.5797],
      ['APEX Beauty - Siam Paragon', 'Siam Paragon, Bangkok', 'Bangkok', 'Daily: 10:00-21:00', '+66 2 129 4888', 'Facial Treatments,Pigmentation', 13.7466, 100.5347],
      ['APEX Beauty - EmQuartier', 'EmQuartier, Sukhumvit, Bangkok', 'Bangkok', 'Daily: 10:00-21:00', '+66 2 003 6888', 'Medical Aesthetics,Microneedling', 13.7310, 100.5695],
      ['APEX Beauty - Dusit Central', 'Dusit Central Park, Bangkok', 'Bangkok', 'Daily: 10:30-22:00', '+66 2 777 8888', 'Advanced Skincare,Anti-Aging', 13.7697, 100.5138],
      ['S-Mart Anti-aging Wellness', 'Bangkok', 'Bangkok', 'Daily: 09:00-19:00', '+66 2 111 5555', 'Anti-Aging,Wellness Programs', 13.7563, 100.5018],
    ];

    const insertMany = db.transaction((clinics) => {
      for (const clinic of clinics) {
        insertClinic.run(...clinic);
      }
    });

    insertMany(defaultClinics);
    console.log(`Seeded ${defaultClinics.length} default clinics`);
  }

  console.log(`Database ready at ${DB_PATH}`);
  return db;
}
