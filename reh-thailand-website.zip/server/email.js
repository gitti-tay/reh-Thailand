import nodemailer from 'nodemailer';

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;

  // If SMTP is configured, use it
  if (process.env.SMTP_HOST) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
    console.log('Email transporter configured with SMTP');
  } else {
    // Use ethereal (test) or just log
    console.log('No SMTP configured — email notifications will be logged to console');
    transporter = null;
  }

  return transporter;
}

const NOTIFICATION_EMAIL = process.env.NOTIFICATION_EMAIL || 'sales@jnacorporation.com';
const FROM_EMAIL = process.env.FROM_EMAIL || 'noreply@reh-thailand.com';

export async function sendNotificationEmail({ type, data }) {
  const transport = getTransporter();

  const templates = {
    demo_request: {
      subject: `🔬 New Demo Request from ${data.name} — ${data.clinic}`,
      html: `
        <div style="font-family: Inter, Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #1447e6, #2b7fff); padding: 24px; border-radius: 12px 12px 0 0;">
            <h1 style="color: white; margin: 0; font-size: 20px;">New Clinical Demo Request</h1>
          </div>
          <div style="background: #f8fafc; padding: 24px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr><td style="padding: 8px 0; color: #64748b; width: 120px;">Name:</td><td style="padding: 8px 0; font-weight: 600;">${data.name}</td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Clinic:</td><td style="padding: 8px 0; font-weight: 600;">${data.clinic}</td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Email:</td><td style="padding: 8px 0;"><a href="mailto:${data.email}">${data.email}</a></td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Phone:</td><td style="padding: 8px 0;">${data.phone || 'Not provided'}</td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Message:</td><td style="padding: 8px 0;">${data.message || 'No message'}</td></tr>
            </table>
            <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #e2e8f0;">
              <p style="color: #64748b; font-size: 12px; margin: 0;">Request ID: #${data.id} — Submitted at ${new Date().toISOString()}</p>
            </div>
          </div>
        </div>
      `,
    },
    partner_enquiry: {
      subject: `🤝 New Partner Enquiry — ${data.clinic_name}`,
      html: `
        <div style="font-family: Inter, Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #059669, #10b981); padding: 24px; border-radius: 12px 12px 0 0;">
            <h1 style="color: white; margin: 0; font-size: 20px;">New Partnership Enquiry</h1>
          </div>
          <div style="background: #f8fafc; padding: 24px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr><td style="padding: 8px 0; color: #64748b; width: 120px;">Clinic:</td><td style="padding: 8px 0; font-weight: 600;">${data.clinic_name}</td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Contact:</td><td style="padding: 8px 0; font-weight: 600;">${data.contact_name}</td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Email:</td><td style="padding: 8px 0;"><a href="mailto:${data.email}">${data.email}</a></td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Phone:</td><td style="padding: 8px 0;">${data.phone || 'Not provided'}</td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Location:</td><td style="padding: 8px 0;">${data.location || 'Not specified'}</td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Message:</td><td style="padding: 8px 0;">${data.message || 'No message'}</td></tr>
            </table>
          </div>
        </div>
      `,
    },
    contact_message: {
      subject: `📬 New Contact Message — ${data.subject || 'General Enquiry'}`,
      html: `
        <div style="font-family: Inter, Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #7c3aed, #a855f7); padding: 24px; border-radius: 12px 12px 0 0;">
            <h1 style="color: white; margin: 0; font-size: 20px;">New Contact Message</h1>
          </div>
          <div style="background: #f8fafc; padding: 24px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr><td style="padding: 8px 0; color: #64748b; width: 120px;">Name:</td><td style="padding: 8px 0; font-weight: 600;">${data.name}</td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Email:</td><td style="padding: 8px 0;"><a href="mailto:${data.email}">${data.email}</a></td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Subject:</td><td style="padding: 8px 0;">${data.subject || 'General'}</td></tr>
              <tr><td style="padding: 8px 0; color: #64748b;">Message:</td><td style="padding: 8px 0;">${data.message}</td></tr>
            </table>
          </div>
        </div>
      `,
    },
  };

  const template = templates[type];
  if (!template) {
    console.warn(`Unknown email template type: ${type}`);
    return;
  }

  if (!transport) {
    console.log(`📧 [EMAIL LOG] ${template.subject}`);
    console.log(`   To: ${NOTIFICATION_EMAIL}`);
    console.log(`   Data:`, JSON.stringify(data, null, 2));
    return;
  }

  try {
    await transport.sendMail({
      from: `"re:H Thailand" <${FROM_EMAIL}>`,
      to: NOTIFICATION_EMAIL,
      subject: template.subject,
      html: template.html,
    });
    console.log(`✅ Email sent: ${template.subject}`);
  } catch (error) {
    console.error(`❌ Email send failed: ${error.message}`);
    throw error;
  }
}
